//using System.Threading.Tasks;

namespace UiS.Dat240.Lab3.Core.Domain.Ordering //.Dto
{
    public enum Status
    {
        New,
        Placed,
        Shipped,
        Delivered,
        Missing,
        Declined
    }
}