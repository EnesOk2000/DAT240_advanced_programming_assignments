using System;
using System.Linq;
using System.Collections.Generic;
using UiS.Dat240.Lab3.SharedKernel;
using UiS.Dat240.Lab3.Core.Domain.Ordering.Events;
using UiS.Dat240.Lab3.Core.Domain.Ordering.Dto;

namespace UiS.Dat240.Lab3.Core.Domain.Ordering{

    public class Order : BaseEntity
	{
        /*public Order(Location location, string customerName, int id) {
            Id = id;
            OrderDate = DateTime.Now;
            OrderLines = orderLines;
            Location = location;
            Notes = "idk";
            Customer = new Customer(id, customerName);
            Status = Status.New;
        }*/
        
        // You have a lot of non-null value warnings. Better watch out.

        public int Id { get; protected set; } //= 1;
        public DateTime OrderDate { get; set; } = DateTime.Now;
        public List<OrderLine> OrderLines { get; set; } = new List<OrderLine>(); //new(); maybe have OrderLine[], no Dto[]
        public Location Location { get; set; } = default!; //new("KE", "456", "By the window");
        public string Notes { get; set; } = "No bones!"; // = default!;
        //? after Notes like this "Notes?". //= default!; // ="default note" (this give it defailt value)
        public Customer Customer { get; set; } = default!; //new Customer(); // = new();
        //public Status Status { get; set; } //= status.New; //= new(); //new Status();

        private Status _status;
		public Status Status
		{
			get => _status;
			set
			{
				if (value == Status.Placed)
				{
					Events.Add(new OrderPlaced(1)); //wtf do I put in here
                    _status = value;
				}
			}
		}
        public void AddOrderLine(OrderLine orderLine){ //Location location, string customerName, OrderLineDto[] orderLines
            //return;
            OrderLines.Add(orderLine);
        }
    }
}