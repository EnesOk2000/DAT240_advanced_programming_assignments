namespace UiS.Dat240.Lab3.Core.Domain.Ordering
{
    public class OrderLine
    {   
        public OrderLine(string item, int amount, decimal price) // int id,
        {
            //Id = id;
            Item = item;
            Amount = amount;
            Price = price;
        }
        public int Id { get; set; }
        public string Item { get; set; } // protected set?
        public int Amount { get; set; }
        public decimal Price { get; set; }
    }
}