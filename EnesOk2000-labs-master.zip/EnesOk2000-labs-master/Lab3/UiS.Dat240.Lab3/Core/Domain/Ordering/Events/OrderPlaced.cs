using UiS.Dat240.Lab3.SharedKernel;

namespace UiS.Dat240.Lab3.Core.Domain.Ordering.Events //
{
	public record OrderPlaced : BaseDomainEvent //
	{
		public OrderPlaced(int n) // 
		{
			ItemId = n;
			//OldPrice = oldPrice; //?? throw new System.ArgumentNullException(nameof(oldPrice)); //
			//NewPrice = newPrice; //?? throw new System.ArgumentNullException(nameof(newPrice)); //
		}
		
		public int ItemId { get; }
		//public decimal OldPrice { get; } ///
		//public decimal NewPrice { get; } //
		
	}
}
