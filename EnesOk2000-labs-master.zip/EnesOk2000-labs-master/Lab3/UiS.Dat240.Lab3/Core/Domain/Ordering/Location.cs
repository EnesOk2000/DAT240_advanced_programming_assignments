﻿using Microsoft.EntityFrameworkCore;

namespace UiS.Dat240.Lab3.Core.Domain.Ordering
{
    [Owned] // makes it a value object (values cannot be changed)
    public class Location
    {   /*
        public Location(string? building, string? roomNumber, string? notes)
        {
            Building = building;
            RoomNumber = roomNumber;
            Notes = notes;
        }*/

        public string? Building { get; set; }
        public string? RoomNumber { get; set; }
        public string? Notes { get; set; }
    }
}
