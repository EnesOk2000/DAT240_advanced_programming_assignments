using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using UiS.Dat240.Lab3.Core.Domain.Ordering;
using UiS.Dat240.Lab3.Core.Domain.Ordering.Dto;
using UiS.Dat240.Lab3.Infrastructure.Data;
using MediatR;
using Microsoft.EntityFrameworkCore;
using UiS.Dat240.Lab3.Core.Domain.Ordering.Events;
using UiS.Dat240.Lab3.SharedKernel;

namespace UiS.Dat240.Lab3.Core.Domain.Ordering.Services
{
    public class OrderingService : IOrderingService
    {
        public OrderingService(ShopContext db) 
            {
                _db = db ?? throw new ArgumentNullException(nameof(db));
                //_os = OrderingService; //?? throw new ArgumentNullException(nameof(OrderingService));
            }
        private readonly ShopContext _db;
        public async Task<int> PlaceOrder(Location location, string customerName, OrderLineDto[] orderLines) // async?? //DTO???
        {
            // 1. Retrieve the customer from the database by name
            var da_customer = _db.Customers //.Include(c => c.Name) //c.Items??? maybe C.something_else lol... // await?
								    //.Where(c => c.Name == customerName);
                                    .SingleOrDefault(c => c.Name == customerName);
									//.SingleOrDefaultAsync(cancellationToken);


            // 2. If the returned object is null,
            // then assign a new customer to the variable, add it to the database and use that customer instead.
            if (da_customer == null)
				{
					da_customer = new Customer(); //what's supposed to be in here? (id, string) or just (string)? or just () ?
                    da_customer.Name = customerName;
					_db.Customers.Add(da_customer);
				}


            // 3. Create a new Order
            Order da_order = new Order();
            // i. Assign the Location, and Customer to the order
            da_order.Location = location;
            da_order.Customer = da_customer;
            // ii. Loop through all the OrderLineDtos and add them to the order.AddOrderLine method.
                //OrderLine ol = new OrderLine();
            // Console.WriteLine("AM INSIDE OrderingService.cs!!!");
            foreach (OrderLineDto old in orderLines)
            {   
                //System.Console.Write(old);
                OrderLine ol = new OrderLine(old.FoodItemName, old.Amount, old.Price); //old.FoodItemId, 
                ol.Id = old.FoodItemId;
                /*Console.WriteLine("OderLine ------------------------------");
                /*Console.WriteLine(ol);
                Console.WriteLine(ol.ToString());
                Console.WriteLine("PRINT EVERYTING IN OLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL");
                Console.WriteLine(ol.Id.ToString());
                Console.WriteLine(ol.Item.ToString());
                Console.WriteLine(ol.Amount.ToString());
                Console.WriteLine(ol.Price.ToString());*/
                da_order.AddOrderLine(ol);
            }
            // iii. The order.AddOrderLine method should add the orderline to a list in the Order.
                // order.AddOrderLine method implemented in Order.cs

            //Console.WriteLine(da_order.Id.ToString());
            // 4. Add the order to the database and save changes
            // Console.WriteLine(da_order.Id);
            // Console.WriteLine(da_order.OrderDate);
            // Console.WriteLine(da_order.OrderLines[0].Item);
            // Console.WriteLine(da_order.Location.RoomNumber);
            // Console.WriteLine(da_order.Notes);
            // Console.WriteLine(da_order.Customer.Name);
            // Console.WriteLine(da_order.Status);


            _db.Orders.Add(da_order);
            //Console.WriteLine(da_order.Id.ToString());
            //Console.WriteLine(da_order.OrderLines[0].ToString());
            //Console.WriteLine(da_order.OrderLines.ToString());
            
            // 5. Update the status of the Order to placed and make sure that the OrderPlaced event 
            // is added to the order.event list.
            da_order.Status = Status.Placed;

             ///************************************************************************
            //_db.Update(da_order);  ///*************Might wanna add this back***************************
             ///************************************************************************
             
            // _db.Orders.Update(da_order); //_db.Attach(item).State = EntityState.Modified; 
            // ???????????? what more ???????? ORDER EVENT LIST WHAT
            //Events.Add(new ());



            // 6. Save the new changes to the database
            await _db.SaveChangesAsync();
            // System.Console.WriteLine("Order created and placed!");
            return da_order.Id; //1
            //return Task.FromResult(1);
            //_orderingService.PlaceOrder(bla bla bla)
        }
    }
}

// return _db.FoodItems.ToArrayAsync(); // await??
// idk, do the place order thing.

/*
if (order == null)
{
    order = new();
    order.AddOrderLine(location, customerName, orderLines);
    return;
}
item.AddOne();
*/

//return Task<int>.CompletedTask;
//return;

/*
var order = new Order{
    Id = default, //auto increment??
    OrderDate = default, //system.datetime (now)
    OrderLines = orderLines,
    Location = location,
    Notes = default, //idk
    Customer = (default, customerName), //hmmm get customer ID based on name?? no. hm idk. maybe just give custmr and id.
    Status = status // "New"
}; 
Console.Write(order);
return Task(1);
*/

////public int id = 1;

/*
//return await new Order(( location, customerName, orderLines));
            var order = await Task.FromResult(new Order(location, customerName, orderLines, id));
            //_db.FoodItems.FindAsync(id);
            id++;
            return id;

            //sjekke custmer
                //hvis customer finnes: bruk samme customer
                //hvis ikke lag ny customer og bruk den
            // place en ny order i databasen i Order-tabellen
*/