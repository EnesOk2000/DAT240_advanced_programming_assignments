﻿// I think this is the same as CartCheckout in task 2. iii.
/*
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using UiS.Dat240.Lab3.Infrastructure.Data;
using MediatR;
using Microsoft.EntityFrameworkCore;
using UiS.Dat240.Lab3.Core.Domain.Ordering.Services;

namespace UiS.Dat240.Lab3.Core.Domain.Cart.Pipelines
{
	public class PlaceOrder
	{
		public record Request(Guid CartId, string CustomerName, Ordering.Location DeliveryLocation) : IRequest<Response>; //string DeliveryLocation

		public record Response(int OrderId);

		public class Handler : IRequestHandler<Request, Response>
		{
			private readonly ShopContext _db;
            private readonly IOrderingService OrderingService; /// BIG O OR small o??
			// Include this (over and under) service as a dependency like any other dependency
            public Handler(ShopContext db, IOrderingService OrderingService) 
            {
                _db = db ?? throw new ArgumentNullException(nameof(db));
                _orderingService = OrderingService ?? throw new ArgumentNullException(nameof(OrderingService));
            }

            public async Task<Response> Handle(Request request, CancellationToken cancellationToken)
			{
				


				var cart = _db.ShoppingCart.Include(c => c.Items).SingleOrDefault(c => c.Id == request.CartId);
				if (cart == null)
				{
					cart = new ShoppingCart(request.CartId);
					_db.ShoppingCart.Add(cart);
				}

				_orderingService.PlaceOrder()
				//cart.AddItem(request.ItemId, request.ItemName, request.ItemPrice);
				Location loc=request.DeliveryLocation; //new Ordering.Location(
				string cus_nam=request.CustomerName;
				OrderLineDto[] old = {cart.Id, cart.Name, cart.Count, cart.Price};
				int id = 1;

				var _orderingService = new OrderingService();
				var OrderId = _orderingService.PlaceOrder(loc, cus_nam, id);

				_db.ShoppingCart.delete(cart);
				//cart.AddItem(request.ItemId, request.ItemName, request.ItemPrice);
				await _db.SaveChangesAsync(cancellationToken);
				//return Unit.Value;
				return new Response(OrderId); ////star
			}

		}
	}
}


// Get cart items from database
/*
var cart = ....

var OrderId = _orderingService.PlaceOrder(new Ordering.Location(...),
							request.CustomerName,
							cart.Items....
)
*/
//clean up cart. probably delete it.

//return new Response(OrderId); 
//return;