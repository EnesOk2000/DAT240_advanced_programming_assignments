using System;
using System.Linq;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using UiS.Dat240.Lab3.Infrastructure.Data;
using MediatR;
using Microsoft.EntityFrameworkCore;
using UiS.Dat240.Lab3.Core.Domain.Ordering;
using UiS.Dat240.Lab3.Core.Domain.Ordering.Dto;
using UiS.Dat240.Lab3.Core.Domain.Ordering.Events;
using UiS.Dat240.Lab3.Core.Domain.Ordering.Services;
using Microsoft.AspNetCore.Http;

namespace UiS.Dat240.Lab3.Core.Domain.Cart.Pipelines
{
	public class CartCheckout //
	{
		// public record Request(
		// 	// int ItemId,
		// 	// string ItemName,
		// 	// decimal ItemPrice,
		// 	// Guid CartId
        //     ) : IRequest<Unit>;
        

		// public record Response(bool Success, string[] Errors);

        public record Request
        (
            Guid CartId, 
            string CustomerName, 
            Location Loc
        ) : IRequest<Unit>; //string DeliveryLocation

		//public record Response(int OrderId);

		public class Handler : IRequestHandler<Request> //<Request>
		{
			private readonly ShopContext _db;
            private readonly IOrderingService _os; // orderingService
			// public Handler(ShopContext db) => _db = db ?? throw new ArgumentNullException(nameof(db));
            public Handler(ShopContext db, IOrderingService os) 
            {
                _db = db ?? throw new ArgumentNullException(nameof(db));
                _os = os ?? throw new ArgumentNullException(nameof(os));
            }

			public async Task<Unit> Handle(Request request, CancellationToken cancellationToken)
			{
                // Get cart items from database
                // var cart = ....
                // var OrderId = _orderingService.PlaceOrder(new Ordering.Location(...),
                //                             request.CustomerName,
                //                             cart.Items....
                // )
                //clean up cart. probably delete it.
                //return new Response(OrderId); 


                // _orderingService.PlaceOrder()
				// //cart.AddItem(request.ItemId, request.ItemName, request.ItemPrice);
				// Location loc=request.DeliveryLocation; //new Ordering.Location(
				// string cus_nam=request.CustomerName;
				// OrderLineDto[] old = {cart.Id, cart.Name, cart.Count, cart.Price};
				// int id = 1;
				// var _orderingService = new OrderingService();
				// var OrderId = _orderingService.PlaceOrder(loc, cus_nam, id);
				// _db.ShoppingCart.delete(cart);
				// //cart.AddItem(request.ItemId, request.ItemName, request.ItemPrice);
				// await _db.SaveChangesAsync(cancellationToken);
				// //return Unit.Value;
				// return new Response(OrderId); ////star

                // 1. Retrieve cart
                var cart = _db.ShoppingCart.
                                        Include(c => c.Items).
                                        SingleOrDefault(c => c.Id == request.CartId);
                if (cart == null)
				{
					System.Console.Write("Error! Cannot retreive cart cus there is no cart.");
                    return Unit.Value;
				}

                // 2. inserts the cart into the IOrderingService to create an order
                
                //Location loc = new Location(request.Loc.Building, request.Loc.RoomNumber, request.Loc.Notes);
                Location loc = new Location
                {
                    Building = request.Loc.Building, 
                    RoomNumber = request.Loc.RoomNumber, 
                    Notes = request.Loc.Notes
                };
                /*Console.WriteLine("Inside CartCheckout.cs");
                Console.WriteLine(loc.Building);
                Console.WriteLine("OK. Here comes the loc object:");
                Console.WriteLine(loc.ToString());
                Console.WriteLine("OK");*/
                string customerName = request.CustomerName;
                List<OrderLine> ol_list = new List<OrderLine>();
                //OrderLineDto[] old_array; // = new OrderLineDto[];
                //OrderLineDto old = new OrderLineDto();
                // OrderLine ol = new OrderLine(old.FoodItemId, old.FoodItemName, old.Amount, old.Price);
                foreach(CartItem item in cart.Items){
                    OrderLine ol = new OrderLine(item.Name, item.Count, item.Price); //
                    // ol.Item = item.Name;
                    // ol.Amount = item.Count;
                    // ol.Price = item.Price;
                    ol_list.Add(ol);
                    //OrderLineDto old = new OrderLineDto(item.Id, item.Name, item.Count, item.Price);
                    // old.FoodItemName = item.Name;
                    // old.Amount = item.Count;
                    // old.Price = item.Price;
                    // old_array.Add(old);
                }
                List<OrderLineDto> old_list = new List<OrderLineDto>();
                foreach(OrderLine o in ol_list){
                    OrderLineDto old = new OrderLineDto(o.Id, o.Item, o.Amount, o.Price);
                    old_list.Add(old);
                }
                OrderLineDto[] old_array = old_list.ToArray();
                //OrderLineDto[] old_array
                /*Console.WriteLine("Right in front of PlaceOrder()");
                Console.WriteLine(loc);
                Console.WriteLine(loc.ToString());
                Console.WriteLine(customerName);
                Console.WriteLine(customerName.ToString());
                Console.WriteLine(old_array);
                Console.WriteLine(old_array.ToString());*/
                //Console.WriteLine("gonna execute PlaceOrder() now.");
                await _os.PlaceOrder(loc, customerName, old_array); // remove this await maybe?
                //Console.WriteLine("Out of placeorder now!!!!!");
                // 3. the current cart should be closed and removed from the session after it is placed.
                // HttpContext.Session[cart].Remove(); 
                ////// TODO ***********************************************************************************
                // remove cart by this maybe
                _db.ShoppingCart.Remove(cart);
                await _db.SaveChangesAsync(); // remove this await maybe? Is 2 awaits ok??
                //Console.Write("Cart checked out!");

                // 4. Idk return something.
                // return 1;
                return Unit.Value;
			}

		}
	}
}
