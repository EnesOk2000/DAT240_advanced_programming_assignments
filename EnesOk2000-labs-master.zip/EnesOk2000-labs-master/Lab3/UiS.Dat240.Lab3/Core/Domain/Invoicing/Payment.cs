using System;

namespace UiS.Dat240.Lab3.Core.Domain.Invoicing
{
    public class Payment
    {
        public int Id {get; set;}
        public int Amount {get; set;}
    }
}