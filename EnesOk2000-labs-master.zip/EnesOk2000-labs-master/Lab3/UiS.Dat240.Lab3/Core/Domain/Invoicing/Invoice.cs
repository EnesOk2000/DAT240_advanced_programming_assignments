using System;
using System.Linq;
using System.Collections.Generic;
using UiS.Dat240.Lab3.SharedKernel;

namespace UiS.Dat240.Lab3.Core.Domain.Invoicing
{
    public class Invoice : BaseEntity
    {
        public int Id {get; set;}
        public Customer Customer {get; set;} = default!;
        public Address Address {get; set;} = default!;
        public int Amount {get; set;}
        public int OrderId {get; set;}
        public Status Status {get; set;}
    }
}