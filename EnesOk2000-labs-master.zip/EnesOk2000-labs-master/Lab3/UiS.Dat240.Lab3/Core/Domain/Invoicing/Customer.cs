using System;

namespace UiS.Dat240.Lab3.Core.Domain.Invoicing
{
    public class Customer
    {
        public int Id {get; set;}
        public string Name {get; set;} = default!;
    }
}