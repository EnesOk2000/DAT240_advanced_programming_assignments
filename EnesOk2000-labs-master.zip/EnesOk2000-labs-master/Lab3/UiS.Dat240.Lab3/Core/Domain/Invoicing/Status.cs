//using System.Threading.Tasks;

namespace UiS.Dat240.Lab3.Core.Domain.Invoicing //.Dto
{
    public enum Status
    {
        New,
        Paid,
        Overdue,
        Credited
    }
}