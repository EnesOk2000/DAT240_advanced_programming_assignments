﻿/*using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using UiS.Dat240.Lab3.Core.Domain.Ordering.Events;
using UiS.Dat240.Lab3.Infrastructure.Data;
using MediatR;
using Microsoft.EntityFrameworkCore;


namespace UiS.Dat240.Lab3.Core.Domain.Fulfillment.Handlers //EDITED HERE
{
	// THIS IS FROM CART HNDLR: If the Price of a product changes, we want to update that item in existing shopping carts.
	// If an order is placed then we want to trigger the OrderPlaced event and let Fulfillment and Invoicing context know.
	public class OrderPlacedHandler : INotificationHandler<OrderPlaced>
	{
		private readonly ShopContext _db;

		public OrderPlacedHandler(ShopContext db)
			=> _db = db ?? throw new System.ArgumentNullException(nameof(db));

		public async Task Handle(OrderPlaced notification, CancellationToken cancellationToken)
		{	
			var carts = await _db.ShoppingCart.Include(c => c.Items)
							.Where(c => c.Items.Any(i => i.Sku == notification.ItemId))
							.ToListAsync(cancellationToken);
			foreach (var cart in carts)
			{
				foreach (var item in cart.Items.Where(i => i.Sku == notification.ItemId))
				{
					item.Price = notification.NewPrice;
				}
			}
			await _db.SaveChangesAsync(cancellationToken);
		}
	}
}
*/