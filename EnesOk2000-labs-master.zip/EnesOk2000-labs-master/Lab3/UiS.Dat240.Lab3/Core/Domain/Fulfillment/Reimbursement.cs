using System;

namespace UiS.Dat240.Lab3.Core.Domain.Fulfillment
{
    public class Reimbursement{
        public int Id {get; set;}
        public Shipper Shipper {get; set;} = default!;
        public int Amount {get; set;}
        public int InvoiceId {get; set;}
    }
}