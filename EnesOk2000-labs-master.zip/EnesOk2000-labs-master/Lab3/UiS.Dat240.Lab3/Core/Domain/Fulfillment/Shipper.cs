using System;

namespace UiS.Dat240.Lab3.Core.Domain.Fulfillment
{
    public class Shipper
    {
        public int Id {get; set;}
        public string Name {get; set;} = default!;
    }
}