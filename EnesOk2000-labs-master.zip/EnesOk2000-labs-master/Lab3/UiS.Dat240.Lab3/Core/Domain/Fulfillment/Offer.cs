using System;
using System.Linq;
using System.Collections.Generic;
using UiS.Dat240.Lab3.SharedKernel;

namespace UiS.Dat240.Lab3.Core.Domain.Fulfillment
{
    public class Offer : BaseEntity
    {
        public int Id {get; set;} // protected set?
        public int OrderId {get; set;}
        public Shipper Shipper {get; set;} = default!;
        public Reimbursement Reimbursement {get; set;} = default!;
    }
}