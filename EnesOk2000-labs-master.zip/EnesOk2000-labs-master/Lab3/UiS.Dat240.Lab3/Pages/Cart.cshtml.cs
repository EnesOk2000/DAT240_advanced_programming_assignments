﻿using System.Threading.Tasks;
using UiS.Dat240.Lab3.Core.Domain.Cart;
using UiS.Dat240.Lab3.Core.Domain.Cart.Pipelines;
using UiS.Dat240.Lab3.Core.Domain.Ordering;
using UiS.Dat240.Lab3.Helpers;
using MediatR;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Web;
using Microsoft.EntityFrameworkCore;
using MediatR.Pipeline;
using Microsoft.Extensions.DependencyInjection;

namespace UiS.Dat240.Lab3.Pages
{
	public class CartModel : PageModel
	{	
		public Location? l {get; set;} // fra benji. riktig? 
		// public Location.RoomNumber room {get; set;}
		// public Location.Notes notes {get; set;}
		public string? cn {get; set;} 

		private readonly IMediator _mediator;

		public CartModel(IMediator mediator) => _mediator = mediator ?? throw new System.ArgumentNullException(nameof(mediator));

		public ShoppingCart? Cart { get; private set; }

		/*public async Task OnGetAsync()
		{
			var cartId = HttpContext.Session.GetGuid("CartId");
			if (cartId is null) return;

			Cart = await _mediator.Send(new Get.Request(cartId.Value));
		}*/

		// stolen from Benji!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		public async Task OnGetAsync()
        {
            var cartId = HttpContext.Session.GetGuid("CartId");
            if (cartId is null) return;
            Cart = await _mediator.Send(new Get.Request(cartId.Value));
        }

        public async Task<IActionResult> OnPostAsync(Location l, string cn)
        {
			//Console.WriteLine("in the taask action onpostasync function!!!!");
			
            var cartId = HttpContext.Session.GetGuid("CartId");
            //var loc_form = new Location(l.Building, l.RoomNumber, l.Notes); 
			/*Location loc_form = new Location
            {
                Building = l.Building,
                RoomNumber = l.RoomNumber,
                Notes = l.Notes
            };*/
			Location loc_form = new Location();
            loc_form.Building = l.Building;
            loc_form.RoomNumber = l.RoomNumber;
            loc_form.Notes = l.Notes;
			/*Console.WriteLine("Gonna define result now");
			Console.WriteLine(cartId.Value);
			Console.WriteLine(cn);
			Console.WriteLine(l.Building);
			Console.WriteLine(l.RoomNumber);
			Console.WriteLine(l.Notes);
			Console.WriteLine(loc_form);*/
            var result = await _mediator!.Send(new CartCheckout.Request(cartId!.Value, cn, loc_form));  
			//warning says that this might be null. I fixed it by adding a million ! xD
			//Console.WriteLine(result);
			// Console.WriteLine("result defined SUCCESSFULLY!!");
			HttpContext.Session.Remove("CartId");
			return RedirectToPage("Order");

            //return Page(); 

        }
	}
}
