using System.Collections.Generic;
using System.Threading.Tasks;
using UiS.Dat240.Lab3.Core.Domain.Products;
using UiS.Dat240.Lab3.Core.Domain.Ordering;
using MediatR;
using Microsoft.AspNetCore.Mvc.RazorPages;
using UiS.Dat240.Lab3.Infrastructure.Data;
using System;
using System.Linq;
using System.Reflection;
using System.Threading;
using UiS.Dat240.Lab3.Core.Domain.Cart;
using UiS.Dat240.Lab3.SharedKernel;
using Microsoft.EntityFrameworkCore;

namespace UiS.Dat240.Lab3.Pages
{
	public class OrderModel : PageModel
	{   
		private readonly IMediator _mediator;
        private readonly ShopContext _db; //added this

		public OrderModel(IMediator mediator, ShopContext db) //=> _mediator = mediator ?? throw new System.ArgumentNullException(nameof(mediator));
        {
            _mediator = mediator ?? throw new System.ArgumentNullException(nameof(mediator));
            _db = db ?? throw new ArgumentNullException(nameof(db));
        }

		public List<Order> Orders { get; set; } = new();

		public async Task OnGetAsync()
			{
                // await _db.Orders.SingleOrDefaultAsync(); 
                // _db.Orders.OrderBy(i => i.Id).ToListAsync(cancellationToken: cancellationToken);
                // Orders = await _db.Orders.ToListAsync();  
                Orders = await _db.Orders.Include(c=>c.Customer).Include(c=>c.OrderLines).ToListAsync();
            }
            //=> Orders = await _mediator.Send(new Core.Domain.Ordering.Pipelines.Get.Request());
	}
}
