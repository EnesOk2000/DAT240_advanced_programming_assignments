# Labs for DAT240

Useful links:
* QuickFeed https://uis.itest.run/
  
# Deadlines
* Lab1 10.09.2021
* Lab2 01.10.2021
* Lab3 22.10.2021

# Lab1

Lab 1 is about learning the dotnet type system, string manipulation, data types and working with arrays and enumerables.

# Lab2

The second lab is building an asp.net core ordering application.

# Lab3

More info to come at a later point!

# Project

More info to come at a later point!
