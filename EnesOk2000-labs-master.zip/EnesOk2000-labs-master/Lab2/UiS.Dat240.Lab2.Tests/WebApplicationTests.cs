using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace UiS.Dat240.Lab2.Tests
{
    public class WebApplicationTests : IClassFixture<WebApplicationFactory<Startup>>
    {
        private readonly WebApplicationFactory<Startup> factory;

        public WebApplicationTests(WebApplicationFactory<Startup> factory)
        {
            // This is a way to mock the asp.net core server, and we use it 
            // to gain access to the DI container
            this.factory = factory;
        }

        [Theory]
        [InlineData(" ", " ", 0)]
        [InlineData("nam", " ", 0)]
        [InlineData(" ", "des", 0)]
        [InlineData(" ", " ", 1)]
        [InlineData("nam", "des", 0)]
        [InlineData("name", " ", 1)]
        [InlineData(" ", "des", 1)]

        [InlineData("nam", "des", 1)]

        //[Fact]
        public void IFoodItemValidatorTests(string n, string d, int p)
        {
            // itemValidator will be null if it is not registered in the DI container
            var itemValidator = factory.Services.GetService<IFoodItemValidator>();
            // Use "Assert...." to verify different scenarioes.
            // This will show up when running dotnet test when
            // standing in the test project directory.
            Assert.NotNull(itemValidator);

            var iv2 = new FoodItemValidator();
            FoodItem i = new FoodItem
            {
                Name=n,
                Description=d,
                Price=p
            };
            string[] err_arr = iv2!.IsValid(i);
            Assert.Empty(err_arr); //NotEmpty(err_arr);
        }
    }
}