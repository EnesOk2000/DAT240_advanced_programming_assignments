using System.Threading.Tasks;
//using Bogus;
using Microsoft.EntityFrameworkCore;
using System;

namespace UiS.Dat240.Lab2.Services {

    public class FoodItemProvider : IFoodItemProvider
    {
        private readonly ShopContext _db;

        public FoodItemProvider(ShopContext db)
        {
            _db = db;
        }

        public async Task<FoodItem[]> GetItems()
        {
            return await _db.FoodItems.ToArrayAsync();
            //  return Task.FromResult( new Faker<FoodItem>()
            //     .RuleFor(i=>i.Name, f=>f.Lorem.Sentence(3,2))
            //     .RuleFor(i=>i.Description, f=>f.Lorem.Sentence(10,10))
            //     .RuleFor(i=>i.Price, f=>f.Random.Number(50,250) + .99d)
            //     .RuleFor(i=>i.CookTime, f=>f.Random.Number(5,20))
            //     .Generate(30).ToArray() );
        }
        public async Task AddFoodItem(FoodItem item) //public Task AddFoodItem(FoodItem item)
        {
            // throw new System.NotImplementedException();
            // TODO !!!!!!!!!!
            _db.FoodItems.Add(item);
            // RedirectToPage("./Index");
            await _db.SaveChangesAsync();
            return;
        }

        public async Task<FoodItem> GetFoodItem(int id)
        {
            return await _db.FoodItems.FindAsync(id); //// MADE CHANGES HERE
        }


        public async Task RemoveFoodItem(int id)
        {
            //throw new System.NotImplementedException();
            _db.FoodItems.Remove(_db.FoodItems.Find(id));
            // RedirectToPage("./Index");
            await _db.SaveChangesAsync();
            return;
        }

        public async Task UpdateFoodItem(int id, FoodItem item)
        {
            //throw new System.NotImplementedException();
            _db.Attach(item).State = EntityState.Modified;
            //_db.Update(item);
            await _db.SaveChangesAsync();
            return;
            /*try
            {
                await _db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                throw new Exception($"Customer {id} not found!");
            }*/
        }

        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string ToString()
        {
            return base.ToString();
        }
    }

} 