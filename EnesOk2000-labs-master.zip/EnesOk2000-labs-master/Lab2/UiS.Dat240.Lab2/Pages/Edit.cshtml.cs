﻿using System.Collections.Generic;
using System.Linq;
using System;
using System.Threading.Tasks;
// using Bogus;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;

namespace UiS.Dat240.Lab2.Pages
{
    public class EditModel : PageModel
    {
        private readonly ILogger<EditModel> _logger;
        private readonly IFoodItemProvider _foodItemProvider;
        private readonly IFoodItemValidator _foodItemValidator;
        public FoodItem item { get; set; }

        [TempData]
        public string err_msg { get; set; }

        [TempData]
        public string exc_msg { get; set; }
        public EditModel(ILogger<EditModel> logger, 
                          IFoodItemProvider foodItemProvider,
                          IFoodItemValidator foodItemValidator)
        {
            _logger = logger;
            _foodItemProvider = foodItemProvider;
            _foodItemValidator = foodItemValidator;;
        }
        public async void OnGet(int id)
        {
           item = await _foodItemProvider.GetFoodItem(id); //1
        }

        public async Task<IActionResult> OnPostAsync(int id)
        {   
            if (!ModelState.IsValid)
            {
                return Page();
            }
            err_msg = "";
            exc_msg = "";
            item = new FoodItem();
            item.Id = id;
            item.Name=Request.Form["Name"];
            item.Description=Request.Form["Description"];
            try{
                item.Price=Convert.ToDouble(Request.Form["Price"]);
                item.CookTime=Convert.ToInt32(Request.Form["CookTime"]);
            }
            catch (FormatException)
            {
                exc_msg = "Price/Cooktime must be numbers and cannot be empty!";
            }
            
            //Validate DA ITEM HERE
            var error_array = _foodItemValidator.IsValid(item);
            if (error_array.Length != 0)
            {
                for(var i=0; i<error_array.Length; i++){
                    err_msg += error_array[i]+"\n";
                }
                return RedirectToPage("/edit"); //Page();
            }
            //Validate DA ITEM HERE



            await _foodItemProvider.UpdateFoodItem(id, item);

            return RedirectToPage("/admin");
        }
    }
}
