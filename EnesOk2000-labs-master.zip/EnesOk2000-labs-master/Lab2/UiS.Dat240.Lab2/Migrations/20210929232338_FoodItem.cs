﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace UiS.Dat240.Lab2.Migrations
{
    public partial class FoodItem : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "FoodItems",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Name = table.Column<string>(type: "TEXT", nullable: true),
                    Description = table.Column<string>(type: "TEXT", nullable: true),
                    Price = table.Column<double>(type: "REAL", nullable: false),
                    CookTime = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FoodItems", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 1, 17, "Et porro facilis atque illum veritatis eum et blanditiis modi quidem qui rem.", "Est et et.", 211.99000000000001 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 28, 10, "Dolores tempore quo dolorum facere illo voluptatem amet repellat ut est eum facere minus qui veniam eos molestiae.", "Porro at aperiam aut.", 144.99000000000001 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 27, 17, "Nobis et tempora optio et distinctio est quia autem doloremque deserunt.", "Ut et voluptas.", 122.98999999999999 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 26, 17, "Sunt repellat ut sed sequi dolorem asperiores commodi nobis similique impedit est dolorem est molestias qui.", "Nam facere ex.", 58.990000000000002 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 25, 17, "Repellendus perspiciatis eum non non repellendus occaecati sint aut sed odit aut qui et nihil nisi sint distinctio.", "Ea in et.", 205.99000000000001 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 24, 11, "Ex magnam odit autem ut nostrum odit sapiente assumenda nemo architecto delectus distinctio quam.", "Ullam non reprehenderit autem.", 71.989999999999995 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 23, 6, "Mollitia cum ducimus exercitationem sed veritatis aut alias iusto inventore et qui incidunt.", "Qui dolores eveniet.", 134.99000000000001 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 22, 13, "Eos recusandae sit dolor vero odio natus laudantium enim voluptas modi id vel autem neque sed.", "Dolores nihil quos beatae aperiam.", 169.99000000000001 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 21, 7, "Quos sint explicabo alias ducimus dolorem iusto vero totam quod sunt at odit eius in vero.", "Quis laudantium ut natus.", 235.99000000000001 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 20, 7, "Voluptatem saepe aliquam id optio illum labore voluptas rerum qui repellat quae qui aliquid alias.", "Nihil consectetur enim tempora ut.", 148.99000000000001 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 19, 19, "Dolorem optio rerum iste debitis alias voluptatum enim omnis quod voluptate doloremque eos sequi corrupti consequuntur.", "Hic non enim deserunt.", 222.99000000000001 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 18, 20, "Placeat omnis sint ut dolorum eligendi est autem tempora alias delectus corrupti vitae aut officiis recusandae optio.", "Quisquam harum labore vel.", 198.99000000000001 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 17, 17, "Quo est velit corrupti sapiente hic ea est sit illum incidunt sequi accusamus reprehenderit soluta qui.", "Aperiam esse tenetur mollitia.", 117.98999999999999 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 16, 9, "Veniam mollitia fugiat aut aut excepturi neque praesentium sit vitae sit.", "Odit voluptas dolorem quidem cum.", 247.99000000000001 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 15, 7, "Reiciendis molestias et vero cum recusandae id minima dolorem ratione in quo eum eum minus ut.", "Pariatur voluptatibus tenetur voluptates et.", 165.99000000000001 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 14, 10, "Architecto eum quod inventore est quae neque labore delectus voluptatem ut quam omnis fugit non.", "Enim repudiandae cupiditate minus dicta.", 55.990000000000002 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 13, 17, "Vero natus doloribus pariatur magni perferendis voluptates laborum voluptatum eius similique necessitatibus quam hic quod nihil optio consequuntur error dolore.", "Id ab quia modi.", 133.99000000000001 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 12, 16, "Iusto et veniam est et est incidunt illum sequi dolore voluptas reprehenderit officia maxime animi quia fugit.", "Sed rerum non aut nulla.", 210.99000000000001 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 11, 12, "Quo blanditiis sequi et iusto quia doloremque at laudantium et excepturi veniam consequatur sunt aut.", "Eveniet delectus est.", 125.98999999999999 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 10, 8, "Magni dolor molestiae temporibus ipsa nulla maxime in aperiam vel qui est amet doloremque fugit suscipit recusandae quibusdam.", "Assumenda quibusdam vitae suscipit eos.", 196.99000000000001 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 9, 18, "Dolor nostrum non animi et et quia pariatur earum dolores dolor dolor.", "Aliquam commodi doloribus.", 249.99000000000001 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 8, 11, "Consequatur voluptate perspiciatis provident velit vel ex eos voluptas laudantium iste est nihil sit.", "Qui voluptatem harum molestias rerum.", 241.99000000000001 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 7, 7, "Tempore quia magni nostrum qui autem nobis sed enim voluptas dolores quo dolores deserunt ut dolore atque excepturi.", "Sed eligendi fugit commodi eum.", 200.99000000000001 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 6, 17, "Deserunt nulla perspiciatis beatae sit sequi minus natus placeat beatae.", "Omnis quia ipsum provident.", 147.99000000000001 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 5, 8, "Dolorem adipisci pariatur iste qui vel qui consequuntur quia error.", "Nam consequuntur sit quo voluptas.", 240.99000000000001 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 4, 9, "Nam tempora doloremque molestias officiis rerum unde magnam voluptatem unde.", "Assumenda autem sit ipsum consectetur.", 245.99000000000001 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 3, 7, "Fugiat possimus architecto aut porro corrupti fuga ut corporis veniam provident sit.", "Aliquam vel delectus.", 250.99000000000001 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 2, 10, "Itaque quae perspiciatis qui praesentium voluptatem quo ex in qui ad.", "Sequi et rerum.", 68.989999999999995 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 29, 10, "Quisquam aperiam voluptas voluptates quasi vero consequuntur nihil quas ut ducimus rem.", "Sapiente ducimus repudiandae eligendi sunt.", 179.99000000000001 });

            migrationBuilder.InsertData(
                table: "FoodItems",
                columns: new[] { "Id", "CookTime", "Description", "Name", "Price" },
                values: new object[] { 30, 15, "Et delectus enim in molestiae error maxime aperiam quia modi et molestiae sit et perspiciatis sequi tempore asperiores in.", "Est eius ratione facilis.", 155.99000000000001 });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "FoodItems");
        }
    }
}
