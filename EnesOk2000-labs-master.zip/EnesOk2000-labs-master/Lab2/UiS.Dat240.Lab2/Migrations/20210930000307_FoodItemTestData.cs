﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace UiS.Dat240.Lab2.Migrations
{
    public partial class FoodItemTestData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "Description", "Name", "Price" },
                values: new object[] { "Odio non est sapiente quod excepturi dolorem explicabo fugit ad doloremque.", "Possimus accusamus quos cum in.", 50.990000000000002 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 18, "Recusandae eveniet harum molestiae est quo ex est tenetur veniam est et pariatur id.", "Et provident enim.", 189.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 13, "Optio facere voluptatum ut est earum vero sed asperiores doloremque tempora animi explicabo quod quas sint aut quia est id.", "Aut quam sint.", 68.989999999999995 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 4,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 5, "Ut cumque aut possimus odio ut ratione sequi cupiditate a eveniet et dignissimos a aliquam et nemo possimus eos consectetur.", "Quis quia molestiae nihil enim.", 112.98999999999999 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 5,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 10, "Optio modi sint unde quaerat omnis voluptas fugit voluptas et quas.", "Est voluptates et eos accusamus.", 121.98999999999999 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 6,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 11, "Harum officiis ut libero error sed quidem eius molestiae laudantium pariatur in aspernatur ad illo eum.", "Consequatur debitis odit est.", 197.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 7,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 13, "Ex fugiat hic provident velit est et numquam ut labore incidunt.", "Amet velit molestiae eum totam.", 209.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 8,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 10, "Architecto voluptate beatae nemo et harum dolores sequi laudantium ea nihil corrupti iusto error quia veniam nobis est sint eligendi.", "Molestiae dolorum ut ea et.", 59.990000000000002 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 9,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 7, "Cupiditate error expedita cupiditate minus voluptatum doloremque hic facere facilis debitis omnis ad est.", "Eaque qui aperiam sit.", 201.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 10,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 15, "Itaque at rerum sapiente rerum porro pariatur ipsa atque et qui.", "Quod ea doloribus maxime.", 63.990000000000002 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 11,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 11, "Non ipsa vel id esse qui id nihil quas beatae cum consectetur.", "Maxime dolor possimus a sed.", 187.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 12,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 14, "Aut quo nesciunt quaerat voluptas quia voluptatem vero reprehenderit ex voluptatibus in qui.", "Aut rerum assumenda provident.", 147.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 13,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 13, "Sed voluptate earum quaerat eum dolore enim earum ut maiores molestiae modi nesciunt illum.", "Ipsa voluptatem perspiciatis unde aut.", 227.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 14,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 7, "Explicabo ad quod velit assumenda minus omnis corrupti tempora voluptatibus sed.", "Quia autem placeat aperiam.", 186.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 15,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 15, "Illum asperiores ut tempora voluptas quibusdam aut corrupti quod suscipit quia ea reprehenderit iure.", "Ipsam quasi dolorem omnis officia.", 112.98999999999999 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 16,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 14, "Omnis ducimus voluptatem atque rerum dolores ut laboriosam vel animi.", "Sit voluptatum sed dolor.", 82.989999999999995 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 17,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 18, "Ut est ad maxime necessitatibus consequatur voluptas quis temporibus dignissimos et omnis facilis ullam ab enim assumenda ut cupiditate.", "Aut nemo excepturi.", 90.989999999999995 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 18,
                columns: new[] { "CookTime", "Description", "Name" },
                values: new object[] { 9, "In velit aut inventore non ea alias nemo molestias vel et corporis officiis rerum sit adipisci pariatur eligendi qui temporibus.", "Debitis magnam in." });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 19,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 10, "Enim doloremque vel pariatur voluptatem ut recusandae ut facilis deleniti qui incidunt nostrum unde suscipit autem labore commodi.", "Ipsam natus et.", 143.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 20,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 6, "Eius ad dicta quos et nisi in eligendi minima eligendi sapiente rerum a itaque ea ut.", "Voluptatem est nemo sit libero.", 193.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 21,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 9, "Hic aspernatur et eveniet nostrum vel quas nam aliquid minus porro sapiente iste doloribus incidunt necessitatibus porro at inventore.", "Nostrum et ea molestias.", 69.989999999999995 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 22,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 19, "Amet est autem quis vel voluptas non perspiciatis in voluptas soluta ea eveniet consectetur exercitationem provident modi modi dignissimos voluptatibus.", "Molestias nihil deleniti deleniti.", 195.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 23,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 12, "Totam deserunt architecto quam consequatur ducimus ipsam earum aut commodi ut adipisci ut ducimus eum quae.", "In iure ut velit.", 57.990000000000002 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 24,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 9, "Sed aperiam et quia ullam sequi et voluptatibus totam aliquid et architecto consequatur.", "Et reiciendis hic.", 203.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 25,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 11, "Voluptatem dolore quidem minima inventore cupiditate ut itaque amet quas et occaecati nemo officiis eum enim labore perferendis repellendus.", "Ducimus officiis ex iste.", 85.989999999999995 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 26,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 5, "Omnis vero impedit aperiam fuga reprehenderit nihil rerum repellendus eos molestiae et et.", "Nulla minus quis sit.", 102.98999999999999 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 27,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 12, "Saepe debitis veniam quia vero sunt eum voluptatum necessitatibus ea et voluptates eaque et voluptas.", "Nulla repellat iste.", 66.989999999999995 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 28,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 5, "Ducimus ipsam est sequi repudiandae laboriosam voluptatem alias minus vel sint iure eveniet sunt et quia.", "Asperiores consequuntur aut doloribus.", 60.990000000000002 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 29,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 16, "Dolores sapiente aut quis alias et dolorum et minima quo saepe dicta esse totam.", "Asperiores eum a sit sed.", 77.989999999999995 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 30,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 14, "Excepturi reiciendis ullam earum fugit recusandae asperiores numquam corrupti exercitationem similique assumenda esse vel ut et qui eum eveniet.", "Ipsum explicabo occaecati vero.", 146.99000000000001 });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "Description", "Name", "Price" },
                values: new object[] { "Et porro facilis atque illum veritatis eum et blanditiis modi quidem qui rem.", "Est et et.", 211.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 10, "Itaque quae perspiciatis qui praesentium voluptatem quo ex in qui ad.", "Sequi et rerum.", 68.989999999999995 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 3,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 7, "Fugiat possimus architecto aut porro corrupti fuga ut corporis veniam provident sit.", "Aliquam vel delectus.", 250.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 4,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 9, "Nam tempora doloremque molestias officiis rerum unde magnam voluptatem unde.", "Assumenda autem sit ipsum consectetur.", 245.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 5,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 8, "Dolorem adipisci pariatur iste qui vel qui consequuntur quia error.", "Nam consequuntur sit quo voluptas.", 240.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 6,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 17, "Deserunt nulla perspiciatis beatae sit sequi minus natus placeat beatae.", "Omnis quia ipsum provident.", 147.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 7,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 7, "Tempore quia magni nostrum qui autem nobis sed enim voluptas dolores quo dolores deserunt ut dolore atque excepturi.", "Sed eligendi fugit commodi eum.", 200.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 8,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 11, "Consequatur voluptate perspiciatis provident velit vel ex eos voluptas laudantium iste est nihil sit.", "Qui voluptatem harum molestias rerum.", 241.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 9,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 18, "Dolor nostrum non animi et et quia pariatur earum dolores dolor dolor.", "Aliquam commodi doloribus.", 249.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 10,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 8, "Magni dolor molestiae temporibus ipsa nulla maxime in aperiam vel qui est amet doloremque fugit suscipit recusandae quibusdam.", "Assumenda quibusdam vitae suscipit eos.", 196.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 11,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 12, "Quo blanditiis sequi et iusto quia doloremque at laudantium et excepturi veniam consequatur sunt aut.", "Eveniet delectus est.", 125.98999999999999 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 12,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 16, "Iusto et veniam est et est incidunt illum sequi dolore voluptas reprehenderit officia maxime animi quia fugit.", "Sed rerum non aut nulla.", 210.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 13,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 17, "Vero natus doloribus pariatur magni perferendis voluptates laborum voluptatum eius similique necessitatibus quam hic quod nihil optio consequuntur error dolore.", "Id ab quia modi.", 133.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 14,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 10, "Architecto eum quod inventore est quae neque labore delectus voluptatem ut quam omnis fugit non.", "Enim repudiandae cupiditate minus dicta.", 55.990000000000002 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 15,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 7, "Reiciendis molestias et vero cum recusandae id minima dolorem ratione in quo eum eum minus ut.", "Pariatur voluptatibus tenetur voluptates et.", 165.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 16,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 9, "Veniam mollitia fugiat aut aut excepturi neque praesentium sit vitae sit.", "Odit voluptas dolorem quidem cum.", 247.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 17,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 17, "Quo est velit corrupti sapiente hic ea est sit illum incidunt sequi accusamus reprehenderit soluta qui.", "Aperiam esse tenetur mollitia.", 117.98999999999999 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 18,
                columns: new[] { "CookTime", "Description", "Name" },
                values: new object[] { 20, "Placeat omnis sint ut dolorum eligendi est autem tempora alias delectus corrupti vitae aut officiis recusandae optio.", "Quisquam harum labore vel." });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 19,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 19, "Dolorem optio rerum iste debitis alias voluptatum enim omnis quod voluptate doloremque eos sequi corrupti consequuntur.", "Hic non enim deserunt.", 222.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 20,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 7, "Voluptatem saepe aliquam id optio illum labore voluptas rerum qui repellat quae qui aliquid alias.", "Nihil consectetur enim tempora ut.", 148.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 21,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 7, "Quos sint explicabo alias ducimus dolorem iusto vero totam quod sunt at odit eius in vero.", "Quis laudantium ut natus.", 235.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 22,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 13, "Eos recusandae sit dolor vero odio natus laudantium enim voluptas modi id vel autem neque sed.", "Dolores nihil quos beatae aperiam.", 169.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 23,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 6, "Mollitia cum ducimus exercitationem sed veritatis aut alias iusto inventore et qui incidunt.", "Qui dolores eveniet.", 134.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 24,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 11, "Ex magnam odit autem ut nostrum odit sapiente assumenda nemo architecto delectus distinctio quam.", "Ullam non reprehenderit autem.", 71.989999999999995 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 25,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 17, "Repellendus perspiciatis eum non non repellendus occaecati sint aut sed odit aut qui et nihil nisi sint distinctio.", "Ea in et.", 205.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 26,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 17, "Sunt repellat ut sed sequi dolorem asperiores commodi nobis similique impedit est dolorem est molestias qui.", "Nam facere ex.", 58.990000000000002 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 27,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 17, "Nobis et tempora optio et distinctio est quia autem doloremque deserunt.", "Ut et voluptas.", 122.98999999999999 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 28,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 10, "Dolores tempore quo dolorum facere illo voluptatem amet repellat ut est eum facere minus qui veniam eos molestiae.", "Porro at aperiam aut.", 144.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 29,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 10, "Quisquam aperiam voluptas voluptates quasi vero consequuntur nihil quas ut ducimus rem.", "Sapiente ducimus repudiandae eligendi sunt.", 179.99000000000001 });

            migrationBuilder.UpdateData(
                table: "FoodItems",
                keyColumn: "Id",
                keyValue: 30,
                columns: new[] { "CookTime", "Description", "Name", "Price" },
                values: new object[] { 15, "Et delectus enim in molestiae error maxime aperiam quia modi et molestiae sit et perspiciatis sequi tempore asperiores in.", "Est eius ratione facilis.", 155.99000000000001 });
        }
    }
}
