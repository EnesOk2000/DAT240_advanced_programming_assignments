using System;
using System.Collections.Generic;

namespace UiS.Dat240.Lab2
{
    public class FoodItemValidator : IFoodItemValidator
    {
        public string[] IsValid(FoodItem item)
        {
            //throw new System.NotImplementedException();
            List<string> error_list = new List<string>();
            if(string.IsNullOrWhiteSpace(item.Name)){
                error_list.Add("The name must be filled.");
            }
            if(string.IsNullOrWhiteSpace(item.Description)){
                error_list.Add("The descrption must be filled.");
            }
            if(0 >= item.Price){
                error_list.Add("Price must be more than 0.");
            }/*
            if(0 >= item.CookTime){
                error_list.Add("Cooktime must be more than 0.");
            }*/
            // The test and lab2 task don't want Cooktime to be verified.
            string[] error_array = error_list.ToArray();
            return error_array;
        }
    }
}