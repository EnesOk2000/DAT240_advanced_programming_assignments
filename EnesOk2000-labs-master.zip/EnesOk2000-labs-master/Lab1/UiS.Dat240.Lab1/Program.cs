﻿using System;
using UiS.Dat240.Lab1.Queues;


namespace UiS.Dat240.Lab1
{
    public class Program
    {
        static void Main(string[] args)
        {
           // TODO: Implement
           string input = "";
           string value = "";
           //int pri = 0;
           //UiS.Dat240.Lab1.Queues.GenericPriorityQueue<string> pq = new UiS.Dat240.Lab1.Queues.GenericPriorityQueue<string>();
           UiS.Dat240.Lab1.Queues.GenericQueue<string> gq = new UiS.Dat240.Lab1.Queues.GenericQueue<string>();
           UiS.Dat240.Lab1.Queues.StringQueue sq = new UiS.Dat240.Lab1.Queues.StringQueue();
           UiS.Dat240.Lab1.Queues.ObjectQueue oq = new UiS.Dat240.Lab1.Queues.ObjectQueue();
           string[] value_array;
           string[] input_split;
           while (input != "exit"){
               //Console.WriteLine("Please enter a command (write 'exit' to exit):");
               Console.Write("> ");
               input = Console.ReadLine();
               input_split = input.Split(" ");
               //Console.WriteLine("You wrote: " + input); // + input
               //Console.WriteLine("The input_split is:");
               // hello
               if (input_split[0] == "add")
               {
                   value = "";
                   value_array = input.Split("add ");
                   Console.Write("You wrote the add command with the value: ");
                   foreach (var item in value_array)
                    {
                        value += item;
                    }
                    Console.WriteLine(value);
                    oq.Enqueue(value);
                    sq.Enqueue(value);
                    gq.Enqueue(value);
                }
                else if (input_split[0] == "rem") 
                {
                    Console.WriteLine("You wrote the remove command.");
                    //output = oq.Dequeue();
                    Console.WriteLine(oq.Dequeue());
                    Console.WriteLine(sq.Dequeue());
                    Console.WriteLine(gq.Dequeue());
                }
                else if (input_split[0] == "size") 
                {
                    Console.WriteLine("You wrote the size command.");
                    Console.WriteLine(oq.Length);
                    Console.WriteLine(sq.Length);
                    Console.WriteLine(gq.Length);
                }
                /*
                else if (input_split[0] == "addpri") 
                {
                    Console.WriteLine("You wrote ADDPRI CMD.");
                    value = "";
                   //value_array = input.Split("addpri ");
                   //pri = Int32.Parse(value_array[0]);
                   //Console.WriteLine(value_array[1]);
                   //Console.Write("You wrote the add command with the value: ");
                   
                   foreach (var item in input_split)
                    {
                        value += item;
                    }
                    Console.WriteLine(value);
                }*/
                else if (input != "exit") 
                {
                    Console.WriteLine("Error. Unknown command.");
                }
           }
           Console.WriteLine("You wrote the exit command.");
        }
    }
}
