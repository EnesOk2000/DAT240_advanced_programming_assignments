﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace UiS.Dat240.Lab1.Queues
{
    public interface IStringQueue
    {
        int Length { get; }
        void Enqueue(string value);
        string Dequeue();
    }

    public class StringQueue : IStringQueue
    {
        public int available_spaces_in_queue = 8;
        public string[] queue = new string[8];
        public int Length 
        {
            get
            {
                return queue.Length - available_spaces_in_queue;
            }
        }
        public void Enqueue(string value)
        {
            if (available_spaces_in_queue == 0)
            {
                this.Grow();
            }
            queue[this.Length] = value;
            available_spaces_in_queue--;
        }
        public string Dequeue()
        {
            if (1>Length)
            {
                throw new System.Exception("The queue is empty.");
            }
            string first_element = queue[0];
            queue = queue.Skip(1).ToArray();
            return first_element;
        }
        public void Grow()
        {
            string[] updated_queue = new string[2*queue.Length];
            System.Array.Copy(queue, updated_queue, queue.Length);
            this.available_spaces_in_queue = updated_queue.Length/2;
            queue = updated_queue;
        }
    }
}

