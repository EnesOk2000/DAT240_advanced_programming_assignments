﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Collections;

namespace UiS.Dat240.Lab1.Queues
{
    public interface IGenericPriorityQueue<T>
    {
        int Length { get; }
        void Enqueue(int priority, T value);
        (int Priority, T Value) Dequeue();
    }

    public class GenericPriorityQueue<T> : IGenericPriorityQueue<T>
    {
        public int available_spaces_in_queue = 8;
        public (int Priority, T Value)[] queue = new (int Priority, T Value)[8];
        public int Length 
        {
            get
            {
                return queue.Length - available_spaces_in_queue;
            }
        }

        public void Enqueue(int priority, T value)
        {
            if (available_spaces_in_queue == 0)
            {
                this.Grow(); //Priority, value
            }
            queue[this.Length] = (priority, value);
            available_spaces_in_queue--;
        }

        public (int Priority, T Value) Dequeue()
        {
            if (1>Length)
            {throw new System.Exception("The queue is empty.");}
            int highest_pri = 0;
            int index = -1;
            int riktig_index = 0;
            foreach((int Priority, T Value) element in queue){ //var
                index++;
                if (element.Item1 > highest_pri){
                    highest_pri = element.Item1;
                    Console.WriteLine(highest_pri);
                    riktig_index = index;
                }
            }
            (int Priority, T Value) pri_element = queue[riktig_index];
            queue = queue.Skip(riktig_index+1).ToArray();
            return pri_element;
        }
        
        public void Grow()
        {
            (int Priority, T Value)[] updated_queue = new (int Priority, T Value)[2*queue.Length];
            System.Array.Copy(queue, updated_queue, queue.Length);
            this.available_spaces_in_queue = updated_queue.Length/2;
            queue = updated_queue;
        }
    }
}
