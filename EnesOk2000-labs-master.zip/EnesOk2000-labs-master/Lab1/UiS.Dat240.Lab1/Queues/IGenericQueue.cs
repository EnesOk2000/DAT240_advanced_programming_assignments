﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Collections;

namespace UiS.Dat240.Lab1.Queues
{
    public interface IGenericQueue<T>
    {
        int Length { get; }
        void Enqueue(T value);
        T Dequeue();
    }

    public class GenericQueue<T> : IGenericQueue<T>, System.Collections.Generic.IEnumerable<T>
    {
        public int available_spaces_in_queue = 8;
        public T[] queue = new T[8];
        public int Length 
        {
            get
            {
                return queue.Length - available_spaces_in_queue;
            }
        }

        public void Enqueue(T value)
        {
            if (available_spaces_in_queue == 0)
            {
                this.Grow();
            }
            queue[this.Length] = value;
            available_spaces_in_queue--;
        }

        public T Dequeue()
        {
            if (1>Length)
            {
                throw new System.Exception("The queue is empty.");
            }
            T first_element = queue[0];
            queue = queue.Skip(1).ToArray();
            return first_element;
        }

        public void Grow()
        {
            T[] updated_queue = new T[2*queue.Length];
            System.Array.Copy(queue, updated_queue, queue.Length);
            this.available_spaces_in_queue = updated_queue.Length/2;
            queue = updated_queue;
        }

        public IEnumerator<T> GetEnumerator(){
            for (int x=0; x<Length; x++){yield return queue[x];}
            //foreach (T element in queue){yield return element;}
        }

        IEnumerator IEnumerable.GetEnumerator(){
            for (int y=0; y<Length; y++){yield return queue[y];}
        }
    }
}
