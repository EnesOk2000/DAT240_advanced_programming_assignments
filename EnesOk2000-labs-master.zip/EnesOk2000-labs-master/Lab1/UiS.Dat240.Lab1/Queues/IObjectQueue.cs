﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace UiS.Dat240.Lab1.Queues
{
    public interface IObjectQueue
    {
        int Length { get; }
        void Enqueue(object value);
        object Dequeue();
    }

    public class ObjectQueue : IObjectQueue
    {
        public int available_spaces_in_queue = 8;
        public object[] queue = new object[8];
        public int Length 
        {
            get
            {
                return queue.Length - available_spaces_in_queue;
            }
        }
        public void Enqueue(object value)
        {
            if (available_spaces_in_queue == 0)
            {
                this.Grow();
            }
            queue[this.Length] = value;
            available_spaces_in_queue--;
        }
        public object Dequeue()
        {
            if (1>Length)
            {
                throw new System.Exception("The queue is empty.");
            }
            object first_element = queue[0];
            queue = queue.Skip(1).ToArray();
            return first_element;
        }
        public void Grow()
        {
            object[] updated_queue = new object[2*queue.Length];
            System.Array.Copy(queue, updated_queue, queue.Length);
            this.available_spaces_in_queue = updated_queue.Length/2;
            queue = updated_queue;
        }
    }
}